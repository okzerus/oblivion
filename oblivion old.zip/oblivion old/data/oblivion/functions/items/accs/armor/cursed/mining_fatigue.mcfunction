effect give @s haste 15 0 true
effect clear @s mining_fatigue
playsound minecraft:entity.evoker.cast_spell master @a ~ ~ ~ 1 1.5
playsound minecraft:block.beacon.power_select master @a ~ ~ ~ 1 1.5
particle minecraft:electric_spark ~ ~1 ~ 0.3 0.6 0.3 0.1 50
particle minecraft:enchanted_hit ~ ~1 ~ 0.3 0.6 0.3 0.1 50
